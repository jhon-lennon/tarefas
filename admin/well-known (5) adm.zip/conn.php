<?php

$conn = mysqli_connect("localhost", "zeyins13_social2", "Lindo1996Kj", "zeyins13_dados2");



if(!$conn){

die("Error: Failed to connect to database!");

}

?>